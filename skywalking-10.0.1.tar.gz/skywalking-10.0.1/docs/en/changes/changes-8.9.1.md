## 8.9.1

#### Project

* Upgrade log4j2 to 2.15.0 for CVE-2021-44228
