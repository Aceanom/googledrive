All SkyWalking exporter(metrics, trace, log) instructions had been moved [here](exporter.md).
