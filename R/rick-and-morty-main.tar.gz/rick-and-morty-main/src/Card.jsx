import {
useLoaderData
} from "react-router-dom";
import { useState,useEffect } from 'react'



export function Card({card}) {

    function statuscolor(status) {
        switch(status) {
            case "Alive": return "green"
            case "Dead": return "red"
            case "unknown": return "grey"
        }

    }

    return (
    <div key={card.id} className="card">
        <div className="charinfo">
            <div className="charinfo1">
                <div className="charname">{card.name}</div> <div className="charname" style={{color: statuscolor(card.status)}}>{card.status}</div>
                
            </div>

            <div className="charinfo2">
                
                <div>{card.gender}</div> <div>{card.origin.name}</div>
            </div>

            <img className="charimg" src={card.image}/>
         </div>

   
    </div>)
}