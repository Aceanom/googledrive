import { BrowserRouter, Route, Routes } from "react-router-dom";

import NavBar from "./components/NavBar/NavBar";
import Home from "./pages/Home/Home";

import "./App.scss";

const App = () => {
  return (
    <BrowserRouter>
      <div className="layout">
        <NavBar />
        <main className="layout__main">
          <Routes>
            <Route path="/" element={<Home />} />
          </Routes>
        </main>
        <footer className="layout__footer">
          <span>Developed using </span>
          <a
            href="https://rickandmortyapi.com/"
            target="_blank"
            rel="noreferrer noopener"
          >
            The Rick and Morty API
          </a>
        </footer>
      </div>
    </BrowserRouter>
  );
};

export default App;
