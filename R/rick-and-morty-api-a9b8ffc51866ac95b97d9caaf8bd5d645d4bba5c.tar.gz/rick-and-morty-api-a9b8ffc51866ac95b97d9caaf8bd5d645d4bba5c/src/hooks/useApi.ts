import axios from "axios";
import { useMemo } from "react";

const useApi = () => {
  const baseURL = "https://rickandmortyapi.com/api";

  return useMemo(() => axios.create({ baseURL }), [baseURL]);
};

export default useApi;
