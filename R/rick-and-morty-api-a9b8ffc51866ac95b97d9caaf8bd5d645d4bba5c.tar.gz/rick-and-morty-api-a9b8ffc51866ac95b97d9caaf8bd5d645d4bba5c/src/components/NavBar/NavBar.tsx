import { Link } from "react-router-dom";
import "./NavBar.scss";

const NavBar = () => {
  return (
    <nav className="nav-bar">
      <Link to="/">
        <img src="./rick-and-morty-brand.png" alt="Rick and Morty" />
      </Link>
    </nav>
  );
};

export default NavBar;
