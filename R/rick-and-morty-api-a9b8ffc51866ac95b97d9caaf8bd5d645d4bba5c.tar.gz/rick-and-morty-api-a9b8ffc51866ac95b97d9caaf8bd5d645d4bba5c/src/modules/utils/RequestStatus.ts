export enum RequestStatus {
  IDLE = "idle",
  ERROR = "error",
  LOADING = "loading",
  SUCCESS = "success",
}
