import { useCallback, useEffect, useMemo, useState } from "react";
import qs from "qs";
import useApi from "../../../hooks/useApi";
import { unwrapAPIResult } from "../../utils/unwrapAPIResult";
import { RequestStatus, Resource } from "../../utils";
import { Character } from "./Character";
import { CharacterStatus } from "./CharacterStatus";
import { Gender } from "./Gender";

type Params = {
  filters?: {
    page?: number;
    name?: string;
    status?: CharacterStatus;
    species?: string;
    type?: string;
    gender?: Gender;
  };
};

const mapFilters = (filters: Params["filters"]) => {
  const { page, name, status, species, type, gender } = filters || {};
  return { page, name, status, species, type, gender };
};

export const useCharacters = ({ filters }: Params) => {
  const [data, setData] = useState<Resource<Character[]>>();
  const [status, setStatus] = useState<RequestStatus>(RequestStatus.IDLE);
  const [errorMessage, setErrorMessage] = useState("");

  const api = useApi();
  const url = useMemo(
    () =>
      filters
        ? "/character?" +
          qs.stringify({ ...mapFilters(filters) }, { arrayFormat: "brackets" })
        : "/character",
    [filters]
  );

  const queryFn = useCallback(async () => {
    try {
      setStatus(RequestStatus.LOADING);

      const data = await unwrapAPIResult<Character[]>(api.get(url));
      console.log("data", data);

      setData(data);
      setStatus(RequestStatus.SUCCESS);
    } catch (error) {
      setStatus(RequestStatus.ERROR);
      // @ts-expect-error : `error` object lacks a type but has a `message` key
      setErrorMessage(error.message);
    }
  }, [api, url]);

  useEffect(() => {
    queryFn();
    // queryFn is memoized with useCallback meaning its reference is stable and doesn't need to be in deps
    // this prevents unnecessary re-renders or an infinite loop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api, url]);

  return { ...data, status, errorMessage, refetch: queryFn };
};
