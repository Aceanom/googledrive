import { CharacterStatus } from "./CharacterStatus";
import { Gender } from "./Gender";

export type Character = {
  id: number;
  name: string;
  status: CharacterStatus;
  type: string;
  gender: Gender;
  origin: {
    name: string;
    url: string;
  };
  location: {
    name: string;
    url: string;
  };
  image: string;
  episode: string[];
  url: string;
  created: string;
};
