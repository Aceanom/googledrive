import { useState,useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import {
useLoaderData,
Link
} from "react-router-dom";
import  {Card} from "./Card.jsx"

function CharList() {
    let [totalpages, cards, pagenum] =  useLoaderData();


  return (
    <>
    <div className="charlist">
    {cards.map((card) => <Link to={`/character/${card.id}`}><Card card={card} long={false}></Card></Link>)}
    </div>

    <div className="pageBar">  
            { pagenum != 1 ? <Link to={`/pages/1`} ><div className="pageButton">1</div></Link>  : null } 
            { pagenum > 3 ?  <div className="pageButton">...</div> : null}
            { pagenum > 2 ?  <Link to={`/pages/` + (pagenum-1)} ><div className="pageButton">{(pagenum-1)}</div></Link>  : null}
            
            <div className="pageButton" style={{fontSize: "29px"}}>{pagenum}</div>  
            {pagenum < totalpages - 1 ? <Link to={`/pages/` + (pagenum+1)} ><div className="pageButton">{pagenum+1}</div></Link>  : null} 
            {pagenum < totalpages - 2 ? <div className="pageButton">...</div>  : null}            
            {pagenum != totalpages ?  <Link to={`/pages/` + totalpages} ><div className="pageButton">{totalpages}</div></Link> : null}
    </div>
    </>
  )
}

export default CharList
