import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import CharList from './CharList.jsx'
import {
  createBrowserRouter,
  RouterProvider,
    redirect,
HashRouter,
Routes,
Route,
Navigate
} from "react-router-dom";
import  {Card} from "./Card.jsx"
import  {FullCard} from "./FullCard.jsx"

async function fetchPage(num) {
    const res = await fetch("https://rickandmortyapi.com/api/character?page=" +num)
    const body = await res.json();

    return [body.info.pages, body.results, num];
}

async function fetchCharacter(num) {
    const res = await fetch("https://rickandmortyapi.com/api/character/" +num)
    const body = await res.json();

    return body;
}

async function fetchExpisode(episodeUrl) {
    const res = await fetch(episodeUrl)
    const body = await res.json();

    return body;
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="pages/1" replace />,
  },
  {
    path: "pages/:pagenum",
    element: <CharList />,
    loader: ({params}) => { let num=Number(params.pagenum); return fetchPage(num)}
  },
  {
    path: "character/:charid",
    element: <FullCard />,
    loader: async ({params}) => { 
            const num=Number(params.charid); 
            const character = await fetchCharacter(num); 
            const episodes = await Promise.all(character.episode.map(async(episodeUrl) => await fetchExpisode(episodeUrl)))

            return [character, episodes]}
  },
        
]);


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
