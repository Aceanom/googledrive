import {
useLoaderData
} from "react-router-dom";
import { useState,useEffect } from 'react'

export function FullCard() {

    const [episodes, setEpisodes] = useState([]);

    const [card, loaderepisodes] = useLoaderData();

    function statuscolor(status) {
        switch(status) {
            case "Alive": return "green"
            case "Dead": return "red"
            case "unknown": return "grey"
        }

    }

    return (
    <div key={card.id} className="fullcard">
        <img className="charimg fullcharimg" src={card.image}/>

        <div className="charinfo">
            <div className="charparamlist">
                <div className="charparam"> <div className="infoName">Name</div>   <div className="charname">{card.name}</div></div> 
                <div className="charparam"> <div className="infoName">Status</div>   <div className="charname" style={{color: statuscolor(card.status)}}>{card.status}</div></div>
                <div className="charparam"> <div className="infoName">Gender</div>  <div> {card.gender}</div> </div>
                <div className="charparam"> <div className="infoName">Origin</div>  <div>{card.origin.name}</div></div>
                <div className="charparam"> <div className="infoName">Location:</div>  <div className="locationName">{card.location.name}</div> </div>
            <div className="charparam"> <div className="infoName">Episodes:</div> <div className="episodes">{loaderepisodes.map((episode, id)=> <div className="episodeName" key={id}>{episode.name}</div>)} </div></div>
        
            </div>

             

            
         </div>

   
    </div>)
}