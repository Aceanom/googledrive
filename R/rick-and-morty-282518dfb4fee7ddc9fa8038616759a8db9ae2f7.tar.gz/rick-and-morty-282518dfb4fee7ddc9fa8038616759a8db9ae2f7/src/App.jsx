import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function Card(character) {

    function statuscolor(status) {
        switch(status) {
            case "Alive": return "green"
            case "Dead": return "red"
            case "unknown": return "grey"
        }

    }

    return (
    <div key={character.id} className="card">
        <div className="charinfo">
            <div className="charinfo1">
                <div className="charname">{character.name}</div> <div className="charname" style={{color: statuscolor(character.status)}}>{character.status}</div>
                
            </div>

            <div className="charinfo2">
                
                <div>{character.gender}</div> <div>{character.origin.name}</div>
            </div>
         </div>

        <img className="charimg" src={character.image}/>
    
    </div>)
}

async function fetchPage(num, setCards) {
    const res = await fetch("https://rickandmortyapi.com/api/character?page=0")
    const body = await res.json();

    setCards(body.results);
}

function App() {
    let [cards, setCards] = useState([]);

    fetchPage(0, setCards)

  return (
    <>
    <div className="charlist">
    {cards.map((card) => Card(card))}
    </div>

    <div className="pageBar"> <div className="pageButton">1</div><div className="pageButton">4</div><div className="pageButton">59</div> </div>
    </>
  )
}

export default App
