import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import {
  createBrowserRouter,
  RouterProvider,
    redirect,
HashRouter,
Routes,
Route,
Navigate
} from "react-router-dom";

function FirstPage() {
   return <Redirect to="/0" />;
}

async function fetchPage(num) {
    const res = await fetch("https://rickandmortyapi.com/api/character?page=" +num)
    const body = await res.json();

    return [body.info.pages, body.results, num];
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="pages/1" replace />,
    children: [
     
    
]
  },
  {
            path: "pages/:pagenum",
            element: <App />,
            loader: ({params}) => { let num=Number(params.pagenum); return fetchPage(num)}
          },
        
]);


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
