import { useState,useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import {
useLoaderData,
Link
} from "react-router-dom";

function Card(character) {

    function statuscolor(status) {
        switch(status) {
            case "Alive": return "green"
            case "Dead": return "red"
            case "unknown": return "grey"
        }

    }

    return (
    <div key={character.id} className="card">
        <div className="charinfo">
            <div className="charinfo1">
                <div className="charname">{character.name}</div> <div className="charname" style={{color: statuscolor(character.status)}}>{character.status}</div>
                
            </div>

            <div className="charinfo2">
                
                <div>{character.gender}</div> <div>{character.origin.name}</div>
            </div>
         </div>

        <img className="charimg" src={character.image}/>
    
    </div>)
}

function App() {
    let [totalpages, cards, pagenum] =  useLoaderData();
    console.log(totalpages,cards,pagenum)


  return (
    <>
    <div className="charlist">
    {cards.map((card) => Card(card))}
    </div>

    <div className="pageBar">  
            { pagenum != 1 ? <div className="pageButton"><Link to={`/pages/1`} >1</Link> </div> : null } 
            { pagenum > 2 ? <div className="pageButton">... <Link to={`/pages/` + (pagenum-1)} >{(pagenum-1)}</Link> </div> : null}
            <div className="pageButton">{pagenum}</div>  
            {pagenum < totalpages - 1 ? <div className="pageButton"><Link to={`/pages/` + (pagenum+1)} >{pagenum+1}</Link> ... </div>  : null} 
            {pagenum != totalpages ? <div className="pageButton"> <Link to={`/pages/` + totalpages} >{totalpages}</Link></div> : null}
    </div>
    </>
  )
}

export default App
