import { AxiosPromise, AxiosResponse } from "axios";

export const unwrapAPIResult = async <T>(
  promise: AxiosPromise<AxiosResponse<T>>
) => {
  const res = await promise;

  return res.data as T;
};
