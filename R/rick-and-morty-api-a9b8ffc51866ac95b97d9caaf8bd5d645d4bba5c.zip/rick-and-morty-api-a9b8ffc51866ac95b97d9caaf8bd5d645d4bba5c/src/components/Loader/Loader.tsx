import "./Loader.scss";

const Loader = () => {
  return (
    <div className="loader">
      <div className="loader__content">
        <div className="loader__content__icon loader__content__icon--base" />
        <div className="loader__content__icon loader__content__icon--neon" />
      </div>
    </div>
  );
};

export default Loader;
