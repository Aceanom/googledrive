import { ReactNode } from "react";
import cn from "classnames";

import "./GridColumn.scss";

type ColumnSize = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;

type Props = {
  col?: ColumnSize;
  className?: string;
  children?: ReactNode;
};

const GridColumn = ({ col, className, children }: Props) => {
  return (
    <div
      className={cn("ui-kit-grid-column", className)}
      style={{ gridColumn: `span ${col}` }}
    >
      {children}
    </div>
  );
};

export default GridColumn;
