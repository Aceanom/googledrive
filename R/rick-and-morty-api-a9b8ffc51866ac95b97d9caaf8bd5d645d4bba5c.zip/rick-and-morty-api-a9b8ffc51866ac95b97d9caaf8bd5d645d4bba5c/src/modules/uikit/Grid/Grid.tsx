import { ReactNode } from "react";
import cn from "classnames";

import "./Grid.scss";

type Props = {
  noGutters?: boolean;
  className?: string;
  children?: ReactNode;
};

const Grid = ({ noGutters, className, children }: Props) => {
  return (
    <div
      className={cn("ui-kit-grid", className, {
        "ui-kit-grid--no-gutters": noGutters,
      })}
    >
      {children}
    </div>
  );
};

export default Grid;
