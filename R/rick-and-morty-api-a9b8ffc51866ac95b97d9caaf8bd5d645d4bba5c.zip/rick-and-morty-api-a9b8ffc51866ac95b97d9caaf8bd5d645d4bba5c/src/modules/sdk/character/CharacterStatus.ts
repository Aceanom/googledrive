export enum CharacterStatus {
  ALIVE = "Alive",
  DEAD = "Dead",
  UNKNWON = "unknown",
}
