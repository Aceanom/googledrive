import { Character, CharacterStatus } from "../../modules/sdk/character";
import Chip, { ChipVariant } from "../../modules/uikit/Chip/Chip";
import "./CharacterCard.scss";

const CHARACTER_STATUS_VARIANT: Record<CharacterStatus, ChipVariant> = {
  [CharacterStatus.ALIVE]: "primary",
  [CharacterStatus.DEAD]: "secondary",
  [CharacterStatus.UNKNWON]: "default",
};

type Props = {
  character: Character;
};

const CharacterCard = ({ character }: Props) => {
  return (
    <article className="character-card">
      <img className="character-card__image" src={character.image} alt="" />
      <div className="character-card__content">
        <h2 className="character-card__content__title">{character.name}</h2>
        <div className="character-card__content__chips">
          <Chip
            title={character.status}
            variant={CHARACTER_STATUS_VARIANT[character.status]}
          />
          <Chip title={character.gender} variant="outlined" />
        </div>
        <p className="character-card__content__location">
          <strong>Location:</strong>
          {character.location.name}
        </p>
      </div>
    </article>
  );
};

export default CharacterCard;
