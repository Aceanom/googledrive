import { useCharacters } from "../../modules/sdk/character";
import Loader from "../../components/Loader/Loader";
import { RequestStatus } from "../../modules/utils";
import CharacterCard from "../../components/CharacterCard/CharacterCard";
import { Grid, GridColumn } from "../../modules/uikit/Grid";
import { useEffect, useState } from "react";

import "./Home.scss";

const Home = () => {
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  const {
    results: characters,
    info,
    status,
  } = useCharacters({
    filters: { page: currentPage },
  });

  return (
    <div className="home">
      <Grid>
        {status === RequestStatus.LOADING && <Loader />}
        {status === RequestStatus.ERROR && (
          <GridColumn col={12}>
            <p>Characters could not be retrieved</p>
          </GridColumn>
        )}
        {status === RequestStatus.SUCCESS &&
          (characters ? (
            characters.map((character) => (
              <GridColumn col={6}>
                <CharacterCard key={character.id} character={character} />
              </GridColumn>
            ))
          ) : (
            <p>No characters were found</p>
          ))}
      </Grid>
      <div className="home__pagination">
        <button
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={info?.count ? currentPage === info.count - 1 : undefined}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default Home;
