import { ReactNode } from "react";
import "./SROnly.scss";

type Props = {
  children: ReactNode;
};

const SROnly = ({ children }: Props) => (
  <span className="ui-kit-sr-only">{children}</span>
);

export default SROnly;
