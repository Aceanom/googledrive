import cn from "classnames";
import "./Chip.scss";

export type ChipVariant = "default" | "primary" | "secondary" | "outlined";

type Props = {
  title: string;
  variant?: ChipVariant;
  className?: string;
};

const Chip = ({ title, variant = "default", className }: Props) => {
  return (
    <div className={cn("ui-kit-chip", `ui-kit-chip--${variant}`, className)}>
      {title}
    </div>
  );
};

export default Chip;
