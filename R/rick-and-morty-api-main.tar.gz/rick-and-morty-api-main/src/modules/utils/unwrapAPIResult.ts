import { AxiosPromise, AxiosResponse } from "axios";
import { Resource } from "./Resource";

export const unwrapAPIResult = async <T>(
  promise: AxiosPromise<AxiosResponse<Resource<T>>>
) => {
  const res = await promise;

  return res.data;
};
