export enum Gender {
  FEMALE = "female",
  MALE = "male",
  GENDERLESS = "genderless",
  UNKNOWN = "unknown",
}
